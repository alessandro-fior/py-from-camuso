import collections


def beep(numero_beep=3, frequenza=2500, durata=1000):
    if numero_beep > 5:
        return
    import winsound
    for quanti in range(1, numero_beep+1):
        winsound.Beep(frequenza, durata)


# beep(2, durata=2000)
# beep(durata=1500, numero_beep=4)

def conta_occorrenze(cercato, lista):
    quante = 0
    for elemento in lista:
        if cercato == elemento:
            quante += 1
    return quante


def statistiche(lista):
    Terna = collections.namedtuple("Terna", ["minimo", "massimo", "media"])

    return Terna(min(lista), max(lista), sum(lista)/len(lista))


def statistiche2(lista):
    return min(lista), max(lista), sum(lista)/len(lista)


def raddoppia(x):
    print(id(x))
    x = ["ciaociao"]
    print(id(x))
    print(f"Nella funzione: {x}")


n = ["ciao"]
print(id(n))
raddoppia(n)
print(id(n))
print(f"Dopo la funzione: {n[0]}")






# elenco = [1, 5, 5, 8, 9, -11, 5]
# stats = statistiche(elenco)
# print(stats.massimo)
#
# minimo, massimo, media = statistiche2(elenco)
# print(media)
#
# conta_5 = conta_occorrenze(5, elenco)
# print(f"Il numero 5 è presente {conta_5} volte")
# print(conta_5 + 3)
#
# beep(15)
