def beep(numero_beep=3, frequenza=2500, durata=1000):
    import winsound
    for quanti in range(1, numero_beep+1):
        winsound.Beep(frequenza, durata)


# beep(2, durata=2000)
# beep(durata=1500, numero_beep=4)

def sommatoria(*numeri):
    somma = 0
    for n in numeri:
        somma = somma + n
    return somma


print(sommatoria())
print(sommatoria(1))
print(sommatoria(1, 2))
print(sommatoria(1, 2, 3, 4, 5, 6))

