# Si vuole simulare l`andamento di un`asta on line che vuole
# sperimentare una conduzione innovativa; ogni partecipante
# farà una sola offerta ed il pezzo messo all`asta sarà aggiudicato
# al partecipante la cui offerta più si avvicina alla media
# calcolata su tutte le offerte; ogni offerta sarà registrata
# come una coppia [email, offerta_in_bitcoin].
#
# Dovrà essere memorizzata una lista di tutte le offerte pervenute.

# Al termine:
# - dalla lista dovrà essere eliminata l`offerta minima e massima
# - dovrà essere costruita una seconda lista contenente
#   solo le offerte che non discostano più del 10% rispetto alla media
#   calcolata su tutte le offerte rimaste
import re


# stufo di inserire dati di prova :)
def SIMULA_inserisci_offerte():
    return [
        ['a@a.com', 1], ['b@b.com', 3.3], ['c@c.com', 4.1], ['d@d.com', 3.8], ['e@e.com', 12]
    ]


def trova_email(email, lista_offerte):
    trovato = False

    for offerta in lista_offerte:
        if offerta[0] == email:
            trovato = True
            break

    return trovato


def media_offerte(lista_offerte):
    somma = 0.0
    for offerta in lista_offerte:
        somma += offerta[1]

    return somma / len(lista_offerte)


# si assume che la lista non sia vuota
def minimo(lista_offerte):
    min = lista_offerte[0][1]

    for offerta in lista_offerte[1:]:
        if offerta[1] < min:
            min = offerta[1]

    return min


# invece del solo valore minimo restituisce
# l`intera offerta [email, valore_offerta]
def offerta_minima(lista_offerte):
    min = lista_offerte[0]

    for offerta in lista_offerte[1:]:
        if offerta[1] < min[1]:
            min = offerta

    return min


# si assume che la lista non sia vuota
def massimo(lista_offerte):
    max = lista_offerte[0][1]
    for offerta in lista_offerte[1:]:
        if offerta[1] > max:
            max = offerta[1]

    return max


# invece del solo valore massimo restituisce
# l`intera offerta [email, valore_offerta]
def offerta_massima(lista_offerte):
    max = lista_offerte[0]

    for offerta in lista_offerte[1:]:
        if offerta[1] > max[1]:
            max = offerta

    return max


def stampa_lista(lista_offerte):
    for offerta in lista_offerte:
        print(f"Email Offerente: {offerta[0]} - Offerta: {offerta[1]} ")


def inserisci_offerte():
    lista = []
    altre_offerte = True

    while altre_offerte:
        offerta = input("Inserisci l`offerta pervenuta (0 per terminare): ")

        try:
            offerta = float(offerta)
        except ValueError:
            print("Formato non valido, riprova ...")
            continue

        if offerta == 0:
            altre_offerte = False  # USCITA DAL CICLO
            continue

        if offerta < 0:
            print("Non possono essere fatte offerte negative!")
            continue

        email = input("Inserire l`email dell`offerente: ")

        if not re.match("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", email):
            print("Email non valida, riprova ...")
            continue

        nuova_offerta = [email, offerta]

        # controllo valido solo se viene fatta la stessa offerta con la stessa mail ... limitato!
        # if nuova_offerta in offerte:
        #     print("Questo utente ha già fatto la sua unica offerta ... respinto!")
        #     continue
        # else:
        #     offerte.append(nuova_offerta)

        if trova_email(email, lista):
            print("Questo utente ha già fatto la sua unica offerta ... respinto!")
            continue
        else:
            lista.append(nuova_offerta)

    return lista


def inserisci_offerte2():
    lista = []
    altre_offerte = True
    errore = False

    while altre_offerte:
        offerta = input("Inserisci l`offerta pervenuta (0 per terminare): ")

        try:
            offerta = float(offerta)
        except ValueError:
            print("Formato non valido, riprova ...")
            errore = True

        if not errore:
            if offerta == 0:
                altre_offerte = False  # USCITA DAL CICLO
            else:

                if offerta < 0:
                    print("Non possono essere fatte offerte negative!")
                else:
                    email = input("Inserire l`email dell`offerente: ")

                    if not re.match("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", email):
                        print("Email non valida, riprova ...")
                    else:
                        nuova_offerta = [email, offerta]
                        if trova_email(email, lista):
                            print("Questo utente ha già fatto la sua unica offerta ... respinto!")
                        else:
                            lista.append(nuova_offerta)

    return lista


# print([x for x in range(0, 100) if x // 2 * 2 != x])


# grazie all`uso di funzioni la complessità del programma principale
# è drasticamente ridotta
# offerte = inserisci_offerte()
offerte = SIMULA_inserisci_offerte()
# offerte = inserisci_offerte2()
stampa_lista(offerte)

print("-"*40)

# eliminiamo l`offerta minima e massima
offerte.remove(offerta_minima(offerte))
offerte.remove(offerta_massima(offerte))
stampa_lista(offerte)

print("-"*40)

# costruiamo una nuova lista con gli elementi rimasti
# che non si discostano più del 10% dalla media dei rimasti
offerta_media = media_offerte(offerte)
print(f"Media: {offerta_media}")

tolleranza = offerta_media/100*10
print(f"Tolleranza 10%: {tolleranza}")


offerte_filtrate = [x for x in offerte if abs(x[1]-offerta_media) < tolleranza]
print("OFFERTE FILTRATE")
stampa_lista(offerte_filtrate)






