from copy import deepcopy

s1 = "ciao"
print("Indirizzo di s1: {0}", format(id(s1)))
s2 = s1
print("Indirizzo di s2: {0}", format(id(s2)))

s2 = "marameo!"
print("Indirizzo di s2: {0}", format(id(s2)))

l1 = [1, 2, 3]
print("Indirizzo di l1: {0}", format(id(l1)))
l2 = deepcopy(l1)
print("Indirizzo di l2: {0}", format(id(l2)))

l2[1] = 99
print(l1[1])
print("Indirizzo di l1 dopo: {0}", format(id(l1)))
print("Indirizzo di l2 dopo: {0}", format(id(l2)))

l1 = [1, 2, ["a", "b"], 3]
l2 = deepcopy(l1[1:3])
print(l2)
l2[1][0] = "Io prima ero la a!"
print(l1)



