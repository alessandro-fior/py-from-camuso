import random


class Dado:

    def __init__(self, numero_facce=6):

        # numero facce del dado
        if numero_facce <= 0:
            raise ValueError("Il numero delle facce deve essere maggiore di zero!")

        self._numero_facce = numero_facce

        # risultato ultimo lancio (valore attuale del dado)
        self._valore = 0

    def lancia(self):
        self._valore = random.randint(1, self._numero_facce)
        return self._valore

    def __str__(self):
        return str(self._valore)


class DadoTruccato(Dado):
    def __init__(self, numero_facce, faccia_truccata):
        super().__init__(numero_facce)
        self._faccia_truccata = faccia_truccata

    def lancia(self):
        # diamo 4 chances alla faccia truccata di uscire
        for _ in range(4):
            if super().lancia() == self._faccia_truccata:
                return self._faccia_truccata

        # poi esce quello che esce ...
        return super().lancia()


d1 = DadoTruccato(6, 3)
for _ in range(10):
    print(d1.lancia())


