import random

# ES 1
# fatti inserire due interi A e B da tastiera stampare tutti i numeri
# nell`intervallo [A,B] (estremi inclusi)

# ES 2
# come il precedente ma escludendo i multipli di 3 e scambiando in automatico
# i valori di A e B nel caso B fosse minore di A
# (stampa da 100 a 5 diventerebbe stampa da 5 a 100)

# ES 3
# fatto inserire un numero N da tastiera simulare un count down
# (inserito 50 -> 50, 49, 48 ... 0

# ES 4
# Da tastiera viene inserita una sequenza di N numeri (N letto da tastiera).
# Quanti numeri della sequenza sono uguali ad un numero D (anch'esso letto da tastiera) ?

# ES 5
# sapendo che N % 2 calcola il resto della divisione di N per 2 stampare i primi
# mille numeri pari maggiori di 5

# ES 6
# indicando import random si potranno generare numeri casuali interi tra
# A e B con random.randint(A, B)
# generare numeri casuali tra 20 e 50 calcolando la loro somma finchè non sarà
# estratto il numero 27 (da non includere nella somma)

