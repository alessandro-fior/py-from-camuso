# tabella pitagorica del 7
numero = 7
fermati_a = 70
somma = 7

while numero <= fermati_a and somma < 250:
    print(f"{numero} - {somma}")
    numero += 7  # oppure numero = numero + 7
    somma += numero

print("-"*25)
numero = 7
somma = 7

while numero <= fermati_a and somma <= 250:

    print(f"{numero} - {somma}")
    numero += 7  # oppure numero = numero + 7

    dato = input("Inserire fattore correttivo: ")

    if dato == 100:
        break

    somma += numero + int(dato)
    # ecc.
    # ecc.

print("-"*25)
numero = 7
somma = 7

while numero <= fermati_a and somma <= 250:

    print(f"{numero} - {somma}")
    numero += 7  # oppure numero = numero + 7

    dato = input("Inserire fattore correttivo: ")

    if int(dato) < 0:
        continue

    somma += numero + int(dato)
    # ecc.
    # ecc.



