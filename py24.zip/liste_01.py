import random
lista_vuota = []
numeri_pari = [2, 4, 6, 8, 10]
print(numeri_pari)

# lista = [espressione for variabile in sequenza]
# list comprehension
numeri_dispari = [numero - 1 for numero in numeri_pari]
print(numeri_dispari)

primi_10 = [x for x in range(1, 11)]
print(primi_10)

minori_40_no_3x = [x for x in range(1, 40) if x % 3 != 0]
print(minori_40_no_3x)

# senza_vocali = [c for c in input() if c not in "aeiou"]
senza_vocali = [c for c in "salve mondo!" if c not in "aeiou"]

print(senza_vocali)
print("".join(senza_vocali))
print(len(senza_vocali))

lista = [1, 2, 3, 4, 41, 96, 17, -8, 90]
terzo = lista[2]
print(terzo)

gruppo_estratto = lista[:]
del(gruppo_estratto[4])
print(gruppo_estratto)
print(lista)

lista.append(100)
print(lista)

lista.extend(x for x in range(101, 111))
print(lista)

lista.insert(3, 77)
print(lista)

lista.remove(105)
print(lista)

if 108 in lista:
    print("trovato")

try:
    posizione = lista.index(-88)
    trovato = True
except ValueError:
    trovato = False

print(trovato)

for elemento in lista:
    print(elemento)

for indice, valore in enumerate(lista):
    print(f"Alla posizione {indice} si trova l`elemento {valore}")

indice = 0
while indice < len(lista):
    print(f"{indice} - {lista[indice]}")
    indice = indice + 1
lista2 = ["uno ", "due ", "tre "]
print(max(lista2))
print(sum(lista))
print(max(lista))
print(min(lista))
lista.sort()
print(lista)

lista2 = lista
del(lista2[0])
print(lista)
print(id(lista))
print(id(lista2))

puntoA = [1, 6]
puntoB = [4, 2]
puntoC = [1, 2]
triangolo = [puntoA, puntoB, puntoC]
print(triangolo[0])

cerchio = [puntoA, puntoB, 7]
disegno = [triangolo, cerchio]
print(f"Misura del raggio del cerchio {disegno[1][2]}")

prima_figura = disegno[:1]
print(prima_figura)

numeri = [numero for numero in range(1, 91)]

# simuliamo alcune ruote del lotto
random.shuffle(numeri)
elenco_citta = ["Palermo", "Napoli", "Venezia"]
ruote = []
for citta in range(0, len(elenco_citta)):
    ruote.append([elenco_citta[citta], numeri[5*citta:5*(citta+1)]])

print(ruote)


