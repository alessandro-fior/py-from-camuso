import random

# lista = [1, 2, 3, 4, 5, 6, 7]
# print(lista[6])
#
# for posizione in range(len(lista)):
#     print(lista[posizione])

# for numero in range(1, 101, 3):
#     print(numero)

# for numero in range(10, 1, -1):
#     print(numero)

# tabella pitagorica
for riga in range(1, 11):
    for colonna in range(1, 11):
        print(f"{riga*colonna} ", end="")
    print()

lista = [1, 2, 3, 4, 5, 6, 7]
for numero in lista:
    print(numero)

for carattere in "precipitevolissemevolmente":
    print(carattere)

avverbio = "precipitevolissemevolmente"
for posizione in range(0, len(avverbio), 3):
    print(avverbio[posizione])
