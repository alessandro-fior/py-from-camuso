import random
import time

# ES 1
# fatti inserire due interi A e B da tastiera stampare tutti i numeri
# nell`intervallo [A,B] (estremi inclusi)
# a = input("Inserire estremo inferiore intervallo: ")
# b = input("Inserire estremo superiore intervallo: ")
# a = int(a)
# b = int(b)

# scenario 1: interessa mantenere inalterati A e B
# conta = a
# while conta <= b:
#     print(conta)
#     conta += 1

# scenario 2: NON interessa mantenere inalterati A e B
# while a <= b:
#     print(a)
#     a += 1

print("-"*25)


# ES 2
# come il precedente ma escludendo i multipli di 3 e scambiando in automatico
# i valori di A e B nel caso B fosse minore di A
# (stampa da 100 a 5 diventerebbe stampa da 5 a 100)
# if a <= b:  # scambio
#     partenza = a
#     fine = b
# else:
#     partenza = b
#     fine = a
# while partenza <= fine:
#     print(partenza)
#     partenza += 1

# classico ...
# if b < a:
#     temp = a
#     a = b
#     b = temp
# while a <= b:
#     print(a)
#     a += 1

# più pitonico :)
# partenza = min([a, b])
# fine = max([a, b])
#
# while partenza <= fine:
#     print(partenza)
#     partenza += 1

# il più pitonico ... ma rischioso!
# if b < a:
#     a, b = b, a
# while a <= b:
#     if a % 3 == 0:
#         print(a)
#     a += 1


# ES 3
# fatto inserire un numero N da tastiera simulare un count down
# (inserito 50 -> 50, 49, 48 ... 0
# n = input("Il count down parte da: ")
# n = int(n)
# while n >= 0:
#     print(n)
#     time.sleep(1)
#     n -= 1


# ES 4
# Da tastiera viene inserita una sequenza di N numeri (N letto da tastiera).
# Quanti numeri della sequenza sono uguali ad un numero D (anch'esso letto da tastiera) ?
# d = input("Numero da monitorare: ")
# d = int(d)
# conta = 0
# while n > 0:
#     letto = input("Inserire un numero : ")
#     letto = int(letto)
#
#     if letto == d:
#         conta += 1
#     n -= 1
# print(f"{d} è stato trovato {conta} volte.")

# ES 5
# sapendo che N % 2 calcola il resto della divisione di N per 2 stampare i primi
# mille numeri pari maggiori di 5
n = 6
conta = 0
# while conta < 12:
#     if n % 2 == 0:
#         print(n)
#         conta += 1
#     n += 1

# while conta < 12:
#     print(n)
#     conta += 1
#     n += 2

# ES 6
# indicando import random si potranno generare numeri casuali interi tra
# A e B con random.randint(A, B)
# generare numeri casuali tra 20 e 50 calcolando la loro somma finchè non sarà
# estratto il numero 27 (da non includere nella somma)
somma = 0
numero = 0
while numero != 27:
    numero = random.randint(20, 50)
    if numero != 27:
        somma += numero
print(f"Somma: {somma}")
