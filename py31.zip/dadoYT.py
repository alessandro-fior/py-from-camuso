import random


class Dado:

    def __init__(self, numero_facce=6):

        # numero facce del dado
        if numero_facce <= 0:
            raise ValueError("Il numero delle facce deve essere maggiore di zero!")

        self._numero_facce = numero_facce

        # risultato ultimo lancio (valore attuale del dado)
        self._valore = 0

    def lancia(self):
        self._valore = random.randint(1, self._numero_facce)
        return self._valore

    def __str__(self):
        return str(self._valore)


d1 = Dado(6)
print(f"Prima del lancio {d1}")
d1.lancia()
print(f"Dopo il lancio {d1}")

try:
    d2 = Dado(-20)
except ValueError as errore:
    print(errore)
    exit(1)

conta_17 = 0
for _ in range(100):
    if d2.lancia() == 17:
        conta_17 += 1
print(f"Il numero 17 è uscito {conta_17} volte")
