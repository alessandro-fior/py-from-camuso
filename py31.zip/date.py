
class Data:
    def __init__(self, gg, mm, aa):
        self._gg = gg
        self._mm = mm
        self._aa = aa
        self._giorni = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

        if not self._valida():
            raise ValueError("Data non valida")

    def _valida(self):
        if self._mm < 1 or self._mm > 12 or self._aa < 1800:
            return False

        if self._aa % 4 == 0:
            self._giorni[1] = 29

        if self._gg < 1 or self._gg > self._giorni[self._mm - 1]:
            return False

        return True

    def __gt__(self, other):
        if self._aa > other._aa:
            return True
        else:
            if self._aa == other._aa:
                if self._mm > other._mm:
                    return True
                else:
                    if self._mm == other._mm:
                        if self._gg > other._gg:
                            return True
        return False

    def __eq__(self, other):
        return self._gg == other._gg and \
               self._mm == other._mm and \
               self._aa == other._aa


natale = Data(25, 12, 2018)
una_data = Data(28, 2, 2018)

if natale > una_data:
    print("Natale segue una_data")

festa = Data(25, 12, 2018)
if natale == festa:
    print("È sempre Natale")
