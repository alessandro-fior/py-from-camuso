# Si vuole simulare l`andamento di un`asta on line che vuole
# sperimentare una conduzione innovativa; ogni partecipante
# farà una sola offerta ed il pezzo messo all`asta sarà aggiudicato
# al partecipante la cui offerta più si avvicina alla media
# calcolata su tutte le offerte; ogni offerta sarà registrata
# come una coppia [email, offerta_in_bitcoin].
#
# Dovrà essere memorizzata una lista di tutte le offerte pervenute.

# Al termine:
# - dalla lista dovrà essere eliminata l`offerta minima e massima
# - dovrà essere costruita una seconda lista contenente
#   solo le offerte che non discostano più del 10% rispetto alla media
#   calcolata su tutte le offerte rimaste
import re
offerte = []
altre_offerte = True

while altre_offerte:
    offerta = input("Inserisci l`offerta pervenuta (0 per terminare): ")

    try:
        offerta = float(offerta)
    except ValueError:
        print("Formato non valido, riprova ...")
        continue

    if offerta == 0:
        altre_offerte = False
        continue

    if offerta < 0:
        print("Non possono essere fatte offerte negative!")
        continue

    email = input("Inserire l`email dell`offerente: ")

    if not re.match("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", email):
        print("Email non valida, riprova ...")
        continue

    nuova_offerta = [offerta, email]


print(offerte)





