import math


class Punto:
    def __init__(self, x, y):
        print(self)
        self.x = x
        self.y = y

    def to_string(self):
        return f"({str(self.x)}, {str(self.y)})"


p1 = Punto(19, 1)
print(p1)

print(id(p1))
p2 = Punto(3, 3)
print(id(p2))


# print(p1 - p2)


