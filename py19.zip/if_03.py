# simulazione di una procedura di iscrizione ad una associazione
# requisiti:
#  fino a  25 anni un reddito inferiore ai 15000 euro annui
#  dopo i 25 anni un reddito inferiore a 35000 euro annui

eta_s = input("Inserire l`età -> ")
eta = int(eta_s)  # da stringa a numero

reddito_s = input("Inserire il reddito -> ")
reddito = int(reddito_s)  # da stringa a numero

# tecnica 1: if in cascata
if eta <= 25:
    if reddito <= 15000:
        print("Ha i requisiti")
    else:
        print("Non ha i requisiti")
else:
    if reddito <= 35000:
        print("Ha i requisiti")
    else:
        print("Non ha i requisiti")


# tecnica 2: condizione composta
if (eta <= 25 and reddito <= 15000) or (eta > 25 and reddito <= 35000):
        print("Ha i requisiti")
else:
    print("Non ha i requisiti")

codice_fiscale = "MRNCCD78T45G120F"
if "120" in codice_fiscale:
    print("Codice fiscale localizzato")

if "antilope" > "Zebra":
    print("VERO")

if "antilope".upper() > "Zebra".upper():
    print("VERO")
else:
    print("FALSO")

if codice_fiscale.endswith("120F"):
    print("TRUE")

if codice_fiscale.startswith("MRN"):
    print("TRUE")

posizione = codice_fiscale.find("45G")
if posizione > -1:
    print(f"Trovata alla posizione {posizione}")

print("ciao ciao".isalnum())  # false per lo spazio ...
print("ciaociao".isalnum())   # TRUE
print("ciao123".isalnum())    # TRUE
print("ciao123".isalpha())    # false
print("ciao".isalpha())       # TRUE
print("ciao ".isalpha())      # false per lo spazio
print("ciao123".isdigit())    # false
print("123 34".isdigit())     # false per lo spazio
print("123.89".isdigit())     # false per il punto (solo interi)





