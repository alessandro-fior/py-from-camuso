linguaggio1 = "Python"
linguaggio2 = 'PHP'
linguaggio3 = "C"  # oppure 'C'; non esiste una notazione separata per i singoli caratteri

paragrafo1 = ''' Esempio di doc string
    Io sono una stringa molto lunga che può 
    proseguire su più righe; però ho bisogno di delimitatori speciali
    e cioè i tripli apici e ricordo anche gli a capo'''

paragrafo1bis = """ Esempio di doc string
    Io sono una stringa molto lunga che può 
    proseguire su più righe; però ho bisogno di delimitatori speciali
    e cioè i tripli apici e ricordo anche gli a capo"""


paragrafo2 = (
    "Io sono una stringa molto lunga che può "
    "proseguire su più righe; NON ho bisogno di delimitatori speciali "
    "però ho bisogno di virgolette su ogni riga e di parentesi; NON vado a capo"
)

print(paragrafo1)
print(paragrafo2)


# i-mo carattere
codice_fiscale = "GMPCTT56R30D150C"
print("Mese: " + codice_fiscale[8])

# lunghezza di una stringa
print("Lunghezza del codice fiscale: " + str(len(codice_fiscale)))
print("Codice Controllo: " + codice_fiscale[len(codice_fiscale)-1])

# porzioni di una stinga (slices)
nominativo = codice_fiscale[0:6]  # NB: l`ultima posizione è esclusa!
print(nominativo)
print(codice_fiscale[:6])
print(codice_fiscale[6:])
print(codice_fiscale[-1])
print(codice_fiscale[-4:-1])



