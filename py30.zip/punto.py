import math


class Punto:
    def __init__(self, x, y):
        self._x = x
        self._y = y

    def __str__(self):
        return f"({self._x}, {self._y})"

    def __sub__(self, altro_punto):
        cat1 = altro_punto._x - self._x
        cat2 = altro_punto._y - self._y
        ipo_quadrato = math.pow(cat1, 2) + math.pow(cat2, 2)
        return math.sqrt(ipo_quadrato)

    def set_x(self, valore):
        if valore >= 0:
            self._x = valore

    def get_x(self):
        return self._x

    def _non_dovresti_chiamarmi(self):
        return "ciao"


p1 = Punto(0, 0)
p2 = Punto(1, 1)

p2._x = -90
p2.set_x(-190)
print(p2.get_x())

p2.x = 100
print(p2.x)

p3 = Punto(2, 4)
print(p3.x)
