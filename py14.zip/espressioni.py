import math

# dati numerici
print(5)    # costante letterale intera
print(5+7)
print(5-9)
print(5*9)
print(5/3)
print(100000000000000*9999999999999999)
print(3*2.5)


print(2+5*2)
print(10/100*1000)
print(10 / (100*1000))
print((3-5)*(4+2))
print(((3-5)*(4+2)) / (9+18))
print(7//5)
print(2**5)
print(2**5.5)
print(5%2)

print(math.sqrt(81.990))

x_1 = ((3-5)*(4+2)) / (9+18) * math.sqrt(81.990)
x2 = math.gcd(10, 16)
y = math.sqrt(x_1) * x2

print(x_1)













