import docx

divina = docx.Document("divina1.docx")

sezioni = divina.sections
print("Il documento contiene:")
print("{0} sezioni".format(len(sezioni)))

paragrafi = divina.paragraphs
print("{0} paragrafi".format(len(paragrafi)))

# for p in paragrafi:
#     print(p.text)
#     print("-"*50)

miaLista = []
primoEultimo = [paragrafi[0], paragrafi[-1]]
secondoEterzo = paragrafi[1:3]  # slicing
primi3 = paragrafi[:3]
ultimi2 = paragrafi[-2:]
pari = paragrafi[::2]
tutti = paragrafi[:]

tutti = paragrafi
tutti.append(paragrafi[-1])

for p in paragrafi:
    print(p.text)
    print("-"*50)
