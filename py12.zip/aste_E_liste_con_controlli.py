# Si vuole simulare l`andamento di un`asta on line che vuole
# sperimentare una conduzione innovativa; ogni partecipante
# farà una sola offerta ed il pezzo messo all`asta sarà aggiudicato
# al partecipante la cui offerta più si avvicina alla media
# calcolata su tutte le offerte; ogni offerta sarà registrata
# come una coppia [email, offerta_in_bitcoin].
#
# Dovrà essere memorizzata una lista di tutte le offerte pervenute.

# Al termine:
# - dalla lista dovrà essere eliminata l`offerta minima e massima
# - dovrà essere costruita una seconda lista contenente
#   solo le offerte che non discostano più del 10% rispetto alla media
#   calcolata su tutte le offerte rimaste
import re


def trova_email(email, lista_offerte):
    trovato = False

    for offerta in lista_offerte:
        if offerta[0] == email:
            trovato = True
            break

    return trovato


def media_offerte(lista_offerte):
    somma = 0.0
    for offerta in lista_offerte:
        somma += offerta[1]

    return somma / len(lista_offerte)


# si assume che la lista non sia vuota
def minimo(lista_offerte):
    min = lista_offerte[0][1]

    for offerta in lista_offerte[1:]:
        if offerta[1] < min:
            min = offerta[1]

    return min


# si assume che la lista non sia vuota
def massimo(lista_offerte):
    max = lista_offerte[0][1]
    for offerta in lista_offerte[1:]:
        if offerta[1] > max:
            max = offerta[1]

    return max


def stampa_lista(lista_offerte):
    for offerta in lista_offerte:
        print(f"Email Offerente: {offerta[0]} - Offerta: {offerta[1]} ")


def inserisci_offerte():
    lista = []
    altre_offerte = True

    while altre_offerte:
        offerta = input("Inserisci l`offerta pervenuta (0 per terminare): ")

        try:
            offerta = float(offerta)
        except ValueError:
            print("Formato non valido, riprova ...")
            continue

        if offerta == 0:
            altre_offerte = False  # USCITA DAL CICLO
            continue

        if offerta < 0:
            print("Non possono essere fatte offerte negative!")
            continue

        email = input("Inserire l`email dell`offerente: ")

        if not re.match("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", email):
            print("Email non valida, riprova ...")
            continue

        nuova_offerta = [email, offerta]

        # controllo valido solo se viene fatta la stessa offerta con la stessa mail ... limitato!
        # if nuova_offerta in offerte:
        #     print("Questo utente ha già fatto la sua unica offerta ... respinto!")
        #     continue
        # else:
        #     offerte.append(nuova_offerta)

        if trova_email(email, lista):
            print("Questo utente ha già fatto la sua unica offerta ... respinto!")
            continue
        else:
            lista.append(nuova_offerta)

    return lista


# grazie all`uso di funzioni la complessità del programma principale
# è drasticamente ridotta
offerte = inserisci_offerte()
stampa_lista(offerte)
print(f"Offerta Media: {media_offerte(offerte)}")
print(f"Offerta minima: {minimo(offerte)}")







