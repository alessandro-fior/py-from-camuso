import math

s = input("Inserire un numero -> ")
a = float(s)  # da stringa a numero

s = input("Inserire un altro numero -> ")
b = float(s)

if b == 0:
    print("Non posso svolgere il calcolo: il denominatore è zero")
else:
    print(f"Risultato della divisione tra i numeri inseriti {a/b}")

if a >= 0:
    print(f"La radice quadrata di {a} è {math.sqrt(a)}")

# operatori relazionali: <, <=, ==, >, >=, !=

