# premiato con borsa di studio di 1000 euro se il voto all`esame di stato
# è compreso tra 75 e 90

voto_s = input("Inserire il voto -> ")
voto = int(voto_s)  # da stringa a numero

# tecnica 1: if in cascata
if voto >= 75:
    if voto <= 90:
        print("Ha i requisiti")
    else:
        print("Con un voto così alto si ha accesso ad altre borse di studio")
else:
    print("Il voto è troppo basso")


if voto >= 75:
    if voto <= 90:
        print("Ha i requisiti")
else:
    print("Il voto è troppo basso")

# tecnica 2: condizione composta
# if voto >= 75 and voto <= 90:
if 75 <= voto <= 90:
    print("Ha i requisiti")
else:
    print("Non ha i requisiti")
