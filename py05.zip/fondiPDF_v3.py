# fonde in un solo file tutti i pdf trovati nella cartella di lavoro
from os import listdir
import PyPDF2
import os

# elenco di files e cartelle dentro la cartella di lavoro
listaFiles = listdir()


# apriamo in scrittura il file pdf in cui fondere gli altri
nomeFileDestinazione = input()
PDF_Destinazione = open(nomeFileDestinazione, "wb")  # w=write, b=binary
merger = PyPDF2.PdfFileMerger()

for nomeFile in listaFiles:
    if nomeFile.endswith(".pdf"):
        pdfFile = open(nomeFile, "rb")  # r=read, b=binary
        readerPDF = PyPDF2.PdfFileReader(pdfFile)
        merger.append(readerPDF)
        pdfFile.close()

merger.write(PDF_Destinazione)
PDF_Destinazione.close()




















