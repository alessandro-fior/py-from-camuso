import docx

divina = docx.Document("divina1.docx")

sezioni = divina.sections
print("Il documento contiene:")
print("{0} sezioni".format(len(sezioni)))

paragrafi = divina.paragraphs
print("{0} paragrafi".format(len(paragrafi)))

for p in paragrafi:
    print(p.text)
    print("-"*50)


















# paragrafi[1].text = paragrafi[1].text
#
# for n in range(len(paragrafi)):
#     print("run paragrafo " + str(n) + ": " + str(len(paragrafi[n].runs)))
#     print(paragrafi[n].runs[0].text)
#     print("-"*50)


