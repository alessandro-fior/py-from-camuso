# stampa dei quadrati dei primi 10 numeri interi
for numero in range(int(input()), int(input()) + 1):
    print(str(numero) + ":", end="")
    print(numero*numero)


