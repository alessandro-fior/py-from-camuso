# fondere pdf copiando con un ciclo tutte le pagine da due pdf fondendole in un terzo
import PyPDF2

pdfFile1 = open("doc1.pdf", "rb")  # r=read, b=binary
reader1 = PyPDF2.PdfFileReader(pdfFile1)
print(reader1.numPages)

pdfFile2 = open("doc1Copia_x3.pdf", "wb")  # w=write, b=binary
writer1 = PyPDF2.PdfFileWriter()

for numeroPagina in range(reader1.numPages):
    writer1.addPage(reader1.getPage(numeroPagina))

writer1.write(pdfFile2)
pdfFile1.close()
pdfFile2.close()









